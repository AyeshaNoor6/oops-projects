#include<iostream>
#include"ContactsBook.h"
using namespace std;
int menu();
int main()
{
	int free=0;//i made this to get input from user at different stages. for everything where i needed
	int count = 0;//i made this to keep count of how many contacts lists are created.
	while (1)
	{
		system("cls");
		int choice = menu();
		
		ContactsBook* contact_list = new ContactsBook(free);
		switch (choice)
		{
		case 1:
			while (1)
			{
				cout << "\tEnter Size of list: ";
				cin >> free;
				if (cin.fail() && free <= 1)
				{
					cin.clear();
					cin.ignore(numeric_limits<streamsize>::max(), '\n');
					cout << "Plz enter a Number only.\n";
					continue;
				}
				break;
			}
			delete contact_list;
			contact_list = nullptr;
			contact_list = new ContactsBook(free);
			contact_list->resize(free);
			break;
		case 2:
			Contact contact;
			string n = "ayesha";
			contact.setFirst(n);
			contact.setLast(n);
			n = "11111111111";
			contact.setMobile(n);
			n = "qw";
			contact.setEmail(n);
			contact_list->add_contact(contact);
			break;
		}

		switch (choice)
		{
		case 3:
			contact_list->merge_duplicates();
			break;
		case 4:
			contact_list->save_to_file("contact");
			break;
		case 5:
			contact_list->load_from_file("contact");
			system("pause");
			break;
		case 6:
			contact_list->print_contacts_sorted("first_name");
			system("pause");
			break;
		case 7:
			cout<<contact_list->total_contacts();
			system("pause");
			break;
		case 8:
			int choic;
			cout << "1. BY USER FIRST NAME \n2.BY LAST NAME \n";
			while (1)
			{
				cin >> choic;
				if (choic >= 1 && choic <= 2)
				{
					break;
				}
				cout << "\nEnter valid input: ";
				continue;
			}
			switch (choic)
			{
			case 1:
				contact_list->print_contacts_sorted("first_name");
			case 2:
				contact_list->print_contacts_sorted("last_name");
			}
			system("pause");
			break;
		case 9:
			cout << "exited!";
			system("pause");
			exit(0);
			break;
		}
	}

	system("pause");
}
int menu()
{
	cout << "\tContact Management System";
	cout << "\n1. Create a contact list.";
	cout << "\n2. Add a new contact.";
	cout << "\n3. Merge duplicates.";
	cout << "\n4. Store to file.";
	cout << "\n5. Load from file.";
	cout << "\n6. Print Contacts Sorted.";
	cout << "\n7.  Display count of contacts.";
	cout << "\n8. Search contacts.";
	cout << "\n9. Exit.";
	int choice;
	while (1)
	{
		cout << "\tEnter your choice: ";
		cin >> choice;
		if (cin.fail())
		{
			cin.clear();
			cin.ignore();
			cout << "Plz enter a Number only.\n";
			continue;
		}
			if (choice >= 1 && choice <= 9)
				return choice;
	}
}