#include "Address.h"
#include<string>
using namespace std;

//constructor to initialize all data members

Address::Address(std::string house, std::string street, std::string city, std::string country)
{
	this->house = house;
	this->street = street;
	this->city = city;
	this->country = country;
};

//implementing setter functions here
void Address::setHouse(std::string house_set)
{
	house = house_set;
}
void Address::setCity(std::string city_set)
{
	city = city_set;
}
void Address::setStreet(std::string street_set)
{
	street = street_set;
}
void Address::setCountry(std::string country_set)
{
	country = country_set;
}
//implementing getter functions here
std::string Address::getHouse()
{
	return house;
}
std::string Address::getCity()
{
	return city;
}
std::string Address::getStreet()
{
	return street;
}
std::string Address::getCountry()
{
	return country;
}


//implementing code to check two Addresses are equal are not

bool Address::equals( Address& address)
{
	bool flag1 = false, flag2 = false, flag3 = false, flag4 = false;
	if (house == address.getHouse())
	{   
		flag1 = true;     
	}
	if (street == address.getStreet())
	{
		flag2 = true;
	}
	if (this->city == address.getCity())
	{
		flag3 = true;
	}
	if (this->country == address.getCountry())
	{
		flag4 = true;
	}
	if (flag1 && flag2 && flag3 && flag4)
	{
		return true;
	}
	return false;
}

//implementing code to print address
void Address::print_address()
{
	cout << "\nAddress = " << house << "," << street << "," << city << "," << country << ".";
}

//implementing code to return a copy address

Address Address::copy_address()
{
	Address copy;
	copy.house = this->house;
	copy.city = this->city;
	copy.street = this->street;
	copy.country = this->country;
	return copy;
}
